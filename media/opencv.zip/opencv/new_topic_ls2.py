# Filters
# Porpose of filter in img processing  -> filters for extracting edges and conturs
# Application of filters
# convolution, convolutional neural networks are well known deep learning model 
# for using convolution  there ere convolutions for 3d data and 2d
