import cv2
import numpy as np
# Study of scanning the img

img = cv2.imread('./images/gerry.png')

 

# ims = cv2.resize(img,None,fx=0.5, fy=0.5)
# cv2.imshow('Original', ims)
# cv2.waitKey(0)

# We ll apply such transformation mtrx
# there is a way to extract pts from the img automatically

# corners coordinate
# tl - 28,227
# bl - 131, 987
# br - 730, 860
# tr - 572, 149

# defining the starting point
src_points = np.array(
    [
    [28,227],
    [131, 987],
    [730, 860],
    [572, 149],np.float32
    ]
    # opencv expects this kind of float for mtrx
)

# destination_pts  qill the size of the img we want

# we are mapping addresses of the img to the size of desination image
# size of our final img = 600px, 800px
dest_points = np.array(
    [
        [0,0],
        [0, 800],
        [600,800],
        [600, 0]
    ],np.float32
)
# Next step is to understand transformations e.g rotations, scales
# how to find the Transformations mtrx M we use following method

M = cv2.getPerspectivTransform(src_points, dest_points)

# compute the output img 
# omography perspective the mtrz will be 3 by 3 mtrx

# compute the output img
out_img = cv2.warpPerspective(img,M,(600, 800))
cv2.imshow('Result', out_img)
cv2.waitKey(0)


# to get the points from the img without enetering them manually


