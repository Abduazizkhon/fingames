import cv2
import numpy as np 

# defining of onclick function that is used way below in the code
# call back functions needs some args e.g first is event then x,y are the coordinates of the courser, then flags and params
def onClick(event, x, y, flags, param):
    if event == cv2.EVENT_LBUTTONDOWN:
        if len(src_points) < 4:
            src_points.append([x,y])  
            # plottting the circle to the pt we clicked
            # we r drawing the circle args are the img on what we draw the circle then the center of the pt, then the radius, color ,and -1 for filling with a color
            # why we draw the pt in the copy img not in original one. ? Because the img after rotation will be kept in the original img that we do not want 
            cv2.circle(img_copy,(x,y),10,(0,0,255), -1)
            cv2.imshow('Img', img_copy)



# read the img
img = cv2.imread("./images/gerry.png")

# create a copy of the img
img_copy = img.copy()

# defining the starting pts which are the angles that we use to compute the transformation

# defining starting pts
src_points = []
# defining destination pts
dst_points = np.array(
    [
        [0,0],
        [0,800],
        [600, 800],
        [600, 0]
    ],np.float32
)

# we need to create the window in a way that we click on the img and it will give the pxls
# create the window 
cv2.namedWindow('Img')
# to get the pixel when we click somewhere in the window
# call back functions
# For work qith window
cv2.setMouseCallback('Img', onClick)

# SHow the img
cv2.imshow('Img', img_copy)
cv2.waitKey(0)
cv2.destroyAllWindows()


# commute the matrix M
src_float = np.array(src_points, dtype=np.float32)
M = cv2.getPerspectiveTransform(src_float, dst_points)

# get the final image 
out_img = cv2.warpPerspective(img,M,(600, 800))
out_img = cv2.resize(out_img,None,fx=0.5,fy=0.5)
cv2.imshow('Result', out_img)
cv2.waitKey(0)
cv2.destroyAllWindows()


