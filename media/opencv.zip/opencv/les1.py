import cv2
import numpy as np

#second param angle, 3rd scale
# M = cv2.getRotationMatrix2D((x,y),180, 1)
# with workAffine Transform we pass img and trans and get the transformed img
pts_1 = np.float32([135,45],[385,45], [135,230])
pts_2 = np.float32([135,45],[385,45], [150,230])
# Transformation will be applied to all the pts
# getAffineTransform porpose of the img u have 2 imgs one original another is 
# rotated one  it will return what u need to do with original img to rotatete him as previous one
# getAffineTransform gives Matrix M to know what kind of transformation is applied 
# In order to apply affine transformation u need to have 3 poijnts  
# with prospective transformnation u need at least 4 pts
# after transformation the lines are parallel at the beginning they r parallel after the transformation but angle might change
# But in perspective transformation we r not sure that after the transformation lines will be parrallel as they used to be before transformation 
# points are degrre of freedom for transformation
M = cv2.getAffineTransform(pts_1, pts_2)
dst_img = cv2.warpAffine(pts_1,M,(800,800))
#Also, u need to specify resulting img
print(M)


